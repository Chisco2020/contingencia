[![Build Status](https://travis-ci.com/odoocr/l10n_cr.svg?branch=12.0)](https://travis-ci.com/odoocr/l10n_cr)


Para ayuda y soporte la comunidad de Odoo CR cuenta con un grupo en Telegram: https://t.me/OdooCR


### Localización de Costa Rica para Odoo que incluye:

- Facturación electrónica para Costa Rica [4.3](https://www.hacienda.go.cr/ATV/ComprobanteElectronico/frmAnexosyEstructuras.aspx)

#### Debe hacer clone del branch con la versión de Odoo que desea utilizar. 

##### Odoo V12
BRANCH='12.0'

git clone --branch ${BRANCH} --depth 1 --single-branch https://github.com/odoocr/l10n_cr

Esto es una versión BETA, usar bajo su propio riesgo y responsabilidad
