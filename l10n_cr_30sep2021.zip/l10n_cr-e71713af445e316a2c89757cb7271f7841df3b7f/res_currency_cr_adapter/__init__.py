# copyright  2018 Carlos Wong, Akurey S.A.
# License AGPL-3.0 or later (http://ww.gnu.org/licenses/agpl).

from . import models
