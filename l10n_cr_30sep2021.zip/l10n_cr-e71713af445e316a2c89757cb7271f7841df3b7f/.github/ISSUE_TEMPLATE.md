###### Impacted versions:
* 

###### Steps to reproduce:
* 

###### Current behavior:
*

###### Expected behavior:
*

###### Video/Screenshot link (optional):

[Link or URL](https://github.com/odoocr/l10n_cr)
