# -*- coding: utf-8 -*-
# © 2017 Creu Blanca
# License AGPL-3.0 or later (http://www.gnu.org/licenses/agpl.html).

EtsiNS = 'http://uri.etsi.org/01903/v1.3.2#'
